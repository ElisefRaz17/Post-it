//
//  KelseyAndElise.swift
//  ElisesProject
//
//  Created by Kelsey L on 2/22/20.
//  Copyright © 2020 Kelsey L. All rights reserved.
//

import UIKit
import MapKit

class KelseyAndElise: UIViewController, UISearchBarDelegate {

    
    @IBOutlet weak var myMapView: MKMapView!
    @IBAction func seasrchButton(_ sender: Any){
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        present(searchController, animated: true, completion: nil )
    }
        
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
            //Ignoring User
            self.view.isUserInteractionEnabled = false
            
            //Activity Indicator
            let activityIndicator = UIActivityIndicatorView()
            //activityIndicator.activityIndicatorView.Style = UIActivityIndicatorViewStyle.gray
            activityIndicator.style = UIActivityIndicatorView.Style.medium
            activityIndicator.center = self.view.center
            activityIndicator.hidesWhenStopped = true
            activityIndicator.startAnimating()
            
            self.view.addSubview(activityIndicator)
            
            //hide the search bar
            searchBar.resignFirstResponder()
            dismiss(animated: true, completion: nil)
            
            
            //create the search request
            let searchRequest = MKLocalSearch.Request()
            searchRequest.naturalLanguageQuery = searchBar.text
            let activeSearch = MKLocalSearch(request: searchRequest)
            activeSearch.start { (response, error) in
                
                activityIndicator.stopAnimating()
                self.view.isUserInteractionEnabled = true
                
                if response == nil
                {
                    print("Error")
                }
                else{
                    
                    
                    //Remove annotations
                    let annotations = self.myMapView.annotations
                    self.myMapView.removeAnnotations(annotations)
                    
                    //Getting data
                    let latitude = response?.boundingRegion.center.latitude
                    let longitude = response?.boundingRegion.center.longitude
                    
                    //create annotation
                    let annotation = MKPointAnnotation()
                    annotation.title = searchBar.text
                    annotation.coordinate = CLLocationCoordinate2DMake(latitude!, longitude!)
                    self.myMapView.addAnnotation(annotation)
                    
                    //zooming in on annotation
                    let coordinate:CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
                    //let span = MKCoordinateSpanMake(0.1, 0.1)
                    let span = MKCoordinateSpan.init(latitudeDelta:0.1, longitudeDelta:0.1)
                    //let region = MKCoordinateRegionMake(coordinate, span)
                    let  region = MKCoordinateRegion.init(center:coordinate, span:span)
                    self.myMapView.setRegion(region, animated: true)
                    
                    
             
            }
            
        
        
        
                func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view, typically from a nib.
        }


    }


    /*
    import UIKit
    import MapKit

    class ViewController: UIViewController, UISearchBarDelegate {
        
        @IBOutlet weak var myMapView: MKMapView!
        
        @IBAction func searchButton(_ sender: Any)
        {
            let searchController = UISearchController(searchResultsController: nil)
            searchController.searchBar.delegate = self
            present(searchController, animated: true, completion: nil)
        }
        
        func searchBarSearchButtonClicked(_ searchBar: UISearchBar)
        {
            //Ignoring user
            UIApplication.shared.beginIgnoringInteractionEvents()
            
            //Activity Indicator
            let activityIndicator = UIActivityIndicatorView()
            activityIndicator.style = UIActivityIndicatorView.Style.gray
            activityIndicator.center = self.view.center
            activityIndicator.hidesWhenStopped = true
            activityIndicator.startAnimating()
            
            self.view.addSubview(activityIndicator)
            
            //Hide search bar
            searchBar.resignFirstResponder()
            dismiss(animated: true, completion: nil)
            
            //Create the search request
            let searchRequest = MKLocalSearch
            searchRequest.naturalLanguageQuery = searchBar.text
            
            let activeSearch = MKLocalSearch(request: searchRequest)
            
            activeSearch.start { (response, error) in
                
                activityIndicator.stopAnimating()
                UIApplication.shared.endIgnoringInteractionEvents()
                
                if response == nil
                {
                    print("ERROR")
                }
                else
                {
                    //Remove annotations
                    let annotations = self.myMapView.annotations
                    self.myMapView.removeAnnotations(annotations)
                    
                    //Getting data
                    let latitude = response?.boundingRegion.center.latitude
                    let longitude = response?.boundingRegion.center.longitude
                    
                    //Create annotation
                    let annotation = MKPointAnnotation()
                    annotation.title = searchBar.text
                    annotation.coordinate = CLLocationCoordinate2DMake(latitude!, longitude!)
                    self.myMapView.addAnnotation(annotation)
                    
                    //Zooming in on annotation
                    let coordinate:CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
                    let span = MKCoordinateSpanMake(0.1, 0.1)
                    let region = MKCoordinateRegionMake(coordinate, span)
                    self.myMapView.setRegion(region, animated: true)
                }
                
            }
        }
        
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view, typically from a nib.
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        
    }

     */

   
   
    
  
    
}
}
