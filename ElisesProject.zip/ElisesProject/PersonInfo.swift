//
//  PersonInfo.swift
//  ElisesProject
//
//  Created by Kelsey L on 2/23/20.
//  Copyright © 2020 Kelsey L. All rights reserved.
//

import UIKit

class PersonInfo : UIViewController{
    
    var userFirst : String = ""
    
    @IBOutlet weak var firstName: UITextField!
    
    @IBOutlet weak var lastName: UITextField!
    
    
    
    func submit( sender: Any) {
        
        if let text = lastName.text, text.isEmpty{
            
            return
        }
        
        
        if let text = firstName.text,
            text.isEmpty{
            return
        }
        
        
    }
    
}
